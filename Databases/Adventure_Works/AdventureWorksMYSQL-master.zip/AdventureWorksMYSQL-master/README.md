# Adventure Works MYSQL DB with Foreign Keys

Adventure Works MySQL Database 

This database was adapted from https://sourceforge.net/projects/awmysql/

### Database export from :

MySQL Workbench -> AdventureWorks-MySQL-with-FKs.zip

php-myadmin -> adventureworks-mysql-with-fks-2.zip


## The foreign keys

Custom generated -> AW-FKS.sql

Review the three commented out Foreign Keys at the end of the AW-FKS.sql file.
